### Hexlet tests and linter status:
[![Actions Status](https://github.com/anns7one/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/anns7one/python-project-49/actions)
<a href="https://codeclimate.com/github/anns7one/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/7b79053449dd85cad0c6/maintainability" /></a>
https://asciinema.org/a/jWtAh0d8P7oP4DfSunYE7amO0
https://asciinema.org/a/fWOk3A1lj8jbXoCRuTNeEdzKf